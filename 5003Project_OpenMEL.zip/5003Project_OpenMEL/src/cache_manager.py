import os
import hashlib
import json
from pathlib import Path
from typing import Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)


class CacheManager:
    """简化的缓存管理器"""

    def __init__(self, cache_dir: str, model_name: str):
        self.cache_dir = Path(cache_dir)
        self.model_name = model_name

        # 创建缓存子目录
        self.model_cache_dir = self.cache_dir / "models"
        self.embedding_cache_dir = self.cache_dir / "embeddings"

        # 创建目录
        for directory in [self.model_cache_dir, self.embedding_cache_dir]:
            directory.mkdir(parents=True, exist_ok=True)

        logger.info(f"Cache initialized at: {self.cache_dir}")

    def get_model_cache_path(self) -> str:
        """获取模型缓存路径"""
        return str(self.model_cache_dir)

    def get_embedding_cache_key(self, text: str) -> str:
        """生成文本嵌入的缓存键"""
        text_hash = hashlib.md5(text.encode('utf-8')).hexdigest()
        return f"{text_hash}.json"

    def save_embedding(self, text: str, embedding: Any) -> bool:
        """保存文本嵌入到缓存"""
        try:
            cache_file = self.embedding_cache_dir / self.get_embedding_cache_key(text)
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump({
                    'text': text,
                    'embedding': embedding.tolist() if hasattr(embedding, 'tolist') else embedding
                }, f, ensure_ascii=False)
            return True
        except Exception as e:
            logger.warning(f"Failed to cache embedding: {e}")
            return False

    def load_embedding(self, text: str) -> Optional[Any]:
        """从缓存加载文本嵌入"""
        try:
            cache_file = self.embedding_cache_dir / self.get_embedding_cache_key(text)
            if cache_file.exists():
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                logger.debug(f"Loaded embedding from cache: {text[:50]}...")
                return data['embedding']
        except Exception as e:
            logger.warning(f"Failed to load cached embedding: {e}")
        return None