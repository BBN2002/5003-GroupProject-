import torch
import torch.nn as nn
from torch.optim import AdamW
from transformers import get_linear_schedule_with_warmup
from tqdm import tqdm
import logging
import json

logger = logging.getLogger(__name__)


class InferenceEngine:
    def __init__(self, model, config):
        self.model = model
        self.config = config
        self.device = config.device
        self.model.to(self.device)
        self.model.eval()
        # 禁用梯度计算
        torch.set_grad_enabled(False)

    def predict_batch(self, dataloader):
        """批量预测"""
        all_scores = []

        with torch.no_grad():
            for batch in tqdm(dataloader, desc="Predicting"):
                # 分离可以张量化的数据和需要保留的数据
                tensor_data = {}
                non_tensor_data = {}

                for key, value in batch.items():
                    if isinstance(value, torch.Tensor):
                        tensor_data[key] = value.to(self.device)
                    else:
                        non_tensor_data[key] = value

                # 确保必要的张量存在
                if 'mention_input_ids' not in tensor_data:
                    logger.warning("Skipping batch due to missing tensor data")
                    continue

                similarities, _, _ = self.model(
                    mention_input_ids=tensor_data['mention_input_ids'],
                    mention_attention_mask=tensor_data['mention_attention_mask'],
                    entity_input_ids=tensor_data['entity_input_ids'],
                    entity_attention_mask=tensor_data['entity_attention_mask']
                )

                # 收集结果
                batch_size = similarities.size(0)
                for i in range(batch_size):
                    # 安全地获取非张量数据
                    mention_id = non_tensor_data.get('mention_id', ['unknown'] * batch_size)[i]
                    entity_id = non_tensor_data.get('entity_id', ['unknown'] * batch_size)[i]

                    all_scores.append({
                        'mention_id': mention_id,
                        'entity_id': entity_id,
                        'local_score': float(similarities[i].cpu().numpy())
                    })

        return all_scores


# 简化的训练器（如果需要进行训练）
class TextLocalScorerTrainer:
    def __init__(self, model, config, train_dataloader=None, eval_dataloader=None):
        self.model = model
        self.config = config
        self.train_dataloader = train_dataloader
        self.eval_dataloader = eval_dataloader
        self.device = config.device

        self.model.to(self.device)

        if train_dataloader:
            self.optimizer = AdamW(model.parameters(), lr=config.learning_rate)
            self.criterion = nn.BCEWithLogitsLoss()

    def train_epoch(self, epoch):
        """训练一个epoch"""
        self.model.train()
        total_loss = 0

        progress_bar = tqdm(self.train_dataloader, desc=f"Epoch {epoch}")

        for batch in progress_bar:
            # 移动到设备
            batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                     for k, v in batch.items()}

            self.optimizer.zero_grad()

            # 前向传播
            similarities, _, _ = self.model(
                mention_input_ids=batch['mention_input_ids'],
                mention_attention_mask=batch['mention_attention_mask'],
                entity_input_ids=batch['entity_input_ids'],
                entity_attention_mask=batch['entity_attention_mask']
            )

            # 计算损失
            loss = self.criterion(similarities, batch['label'])

            # 反向传播
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)

            self.optimizer.step()

            total_loss += loss.item()
            progress_bar.set_postfix({'loss': f'{loss.item():.4f}'})

        avg_loss = total_loss / len(self.train_dataloader)
        logger.info(f"Epoch {epoch} average loss: {avg_loss:.4f}")
        return avg_loss