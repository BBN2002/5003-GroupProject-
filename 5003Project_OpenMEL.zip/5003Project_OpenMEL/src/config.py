import os
import torch
from dataclasses import dataclass
from typing import Optional


@dataclass
class ModelConfig:
    # 模型配置
    model_name: str = "./bert-base-uncased"
    max_mention_length: int = 128
    max_entity_length: int = 256
    similarity_metric: str = "cosine"  # "cosine", "dot", "euclidean"
    pooling_strategy: str = "cls"  # "cls", "mean", "max"
    temperature: float = 1.0  # 用于softmax温度缩放

    # 训练配置
    batch_size: int = 32
    learning_rate: float = 2e-5
    num_epochs: int = 0  # 0表示只推理不训练
    warmup_ratio: float = 0.1

    # 设备配置
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    fp16: bool = True

    # 路径配置
    mentions_path: str = "mentions.json"
    expanded_path: str = "mentions_expanded.jsonl"
    output_path: str = "./local_scores.jsonl"
    cache_dir: str = "./model_cache"

    def __post_init__(self):
        """初始化后处理"""
        # 确保缓存目录存在
        os.makedirs(self.cache_dir, exist_ok=True)

        # 验证本地模型是否存在
        if not os.path.exists(self.model_name):
            raise FileNotFoundError(f"本地模型目录不存在: {self.model_name}")

        # 检查必要文件
        required_files = ['config.json', 'vocab.txt']
        for file in required_files:
            file_path = os.path.join(self.model_name, file)
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"模型文件缺失: {file_path}")

        print(f"✅ 使用本地模型: {self.model_name}")