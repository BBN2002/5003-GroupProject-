import json
import networkx as nx
from scipy.sparse.csgraph import minimum_spanning_tree
from difflib import SequenceMatcher
from collections import defaultdict
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import heapq
from collections import defaultdict
# 从文件读取得分数据
def load_scores(file_path):
    scores = []
    with open(file_path, 'r') as f:
        for line in f:
            scores.append(json.loads(line))
    return scores
# 从mentions_expanded.jsonl加载数据
def load_mentions_expanded(file_path):
    mentions = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            data = json.loads(line)
            mentions.append({
                'mention_id': data['mention_id'],
                'expanded_text': data['expanded_text'],
                'mention_text': data.get('mention_text', '')  # 可选保留原始文本
            })
    return mentions
# 从mentions文件加载数据
def load_mentions(file_path):
    with open(file_path, 'r') as f:
        return json.load(f)
# entity-entity相似度函数
def similar_strings(str1, str2):
    return SequenceMatcher(None, str1, str2).ratio()
# 余弦相似度计算函数
def cosine_similarity_text(text1, text2):
    """
    计算两个文本的余弦相似度
    返回归一化到[0,1]的值
    """
    # 创建TF-IDF向量器
    vectorizer = TfidfVectorizer()
    # 将两个文本放入列表并向量化
    try:
        tfidf_matrix = vectorizer.fit_transform([text1, text2])
        # 计算余弦相似度
        cos_sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
        # 归一化到[0,1]
        normalized_sim = (cos_sim + 1) / 2
        # 确保在[0,1]范围内
        return max(0.0, min(1.0, normalized_sim))
    except Exception as e:
        # 如果出错，返回0
        return 0.0

# 构建Tree Cover
def build_tree_cover(K=3):
    # 读取数据
    scores = load_scores('outputs\\local_scores.jsonl')
    mentions = load_mentions('data\\mentions.json')
    mentions_expanded = load_mentions_expanded('data\\mentions_expanded.jsonl')
    # 从mentions_expanded数据构建mention_text_dict
    mention_text_dict = {}
    for mention_expanded in mentions_expanded:
        mention_id = mention_expanded['mention_id']
        expanded_text = mention_expanded['expanded_text']
        mention_text_dict[mention_id] = expanded_text
    
    print(f"{len(mention_text_dict)} expanded_text")
    # 从mentions数据构建entity_text_dict
    entity_text_dict = {}
    for mention in mentions:
        for candidate in mention['candidates']:
            entity_id = candidate['entity_id']
            # 使用实体标题和描述作为文本特征
            text = candidate['entity_title'] + " " + candidate['entity_desc']
            entity_text_dict[entity_id] = text 
    G = nx.Graph()
    # 构建mention-entity边（使用余弦相似度）
    mention_entities = defaultdict(list)
    
    processed_count = 0
    skipped_count = 0
    
    for score in scores:
        mention_id = score['mention_id']
        entity_id = score['entity_id']
        
        # 检查是否都有文本信息
        if mention_id in mention_text_dict and entity_id in entity_text_dict:
            mention_text = mention_text_dict[mention_id]  # expanded_text
            entity_text = entity_text_dict[entity_id]
            
            # 使用余弦相似度计算权重
            similarity = cosine_similarity_text(mention_text, entity_text)
            
            mention_entities[mention_id].append((entity_id, similarity))
            processed_count += 1
        else:
            skipped_count += 1  
    # print(f"处理了{processed_count}个mention-entity对，跳过了{skipped_count}个")
    
    for mention_id, entities in mention_entities.items():
        G.add_node(mention_id, type='mention')
        # 选择top-K实体（按余弦相似度排序）
        top_entities = sorted(entities, key=lambda x: x[1], reverse=True)[:K]
        for entity_id, similarity in top_entities:
            G.add_node(entity_id, type='entity')
            G.add_edge(mention_id, entity_id, weight=similarity, type='mention-entity')
    print(f"adding{len(G.nodes())} nodes and{len(G.edges())}edge")
    # 构建entity-entity边（同样使用余弦相似度）
    entities = [n for n in G.nodes() if G.nodes[n]['type'] == 'entity']
    entity_edge_count = 0
    for i, entity1 in enumerate(entities):
        if entity1 not in entity_text_dict:
            continue     
        
        similarities = []
        for entity2 in entities:
            if entity1 == entity2 or entity2 not in entity_text_dict:
                continue      
            # 使用余弦相似度计算权重
            weight = cosine_similarity_text(
                entity_text_dict[entity1], 
                entity_text_dict[entity2]
            )
            similarities.append((entity2, weight))
     
        # 选择top-K实体连接
        top_entities = sorted(similarities, key=lambda x: x[1], reverse=True)[:K]
        for entity2, weight in top_entities:
            G.add_edge(entity1, entity2, weight=weight, type='entity-entity')
            entity_edge_count += 1
    
    print(f"adding{entity_edge_count}entity-entity edge")
    print(f"final gragh:{G.number_of_nodes()}nodes{G.number_of_edges()}edges")  
    return G
def get_maximum_spanning_tree(G):
    """获取最大生成树（保留权重最大的边）"""
    # 方法：将权重取负，求最小生成树，再恢复
    G_neg = G.copy()
    for u, v, data in G_neg.edges(data=True):
        data['weight'] = -data['weight']
    
    try:
        # 使用Kruskal算法
        mst_edges = list(nx.minimum_spanning_edges(G_neg, algorithm='kruskal', data=True))
        
        mst = nx.Graph()
        for u, v, data in mst_edges:
            # 恢复原始权重
            data['weight'] = -data['weight']
            mst.add_node(u, **G.nodes[u])
            mst.add_node(v, **G.nodes[v])
            mst.add_edge(u, v, **data)
        # print(f"MST构建完成: {mst.number_of_nodes()} 节点, {mst.number_of_edges()} 边")
        return mst
    except Exception as e:
        print(f"MST构建失败: {e}")
        return G
def compute_entity_coherence(entity_id, mst, entity_text_dict):
    """
    计算实体的全局一致性得分
    简化：coherence = 该实体在MST中连接的其他实体的平均相似度
    """
    if entity_id not in mst:
        return 0.0
    
    total_weight = 0.0
    count = 0
    
    for neighbor in mst.neighbors(entity_id):
        if mst.nodes[neighbor]['type'] == 'entity':
            weight = mst[entity_id][neighbor]['weight']
            total_weight += weight
            count += 1
    
    return total_weight / count if count > 0 else 0.0
class UnionFind:
    """并查集实现，用于检测环路"""
    def __init__(self):
        self.parent = {}
        self.rank = {}
    
    def find(self, x):
        if x not in self.parent:
            self.parent[x] = x
            self.rank[x] = 0
            return x
        
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]
    
    def union(self, x, y):
        root_x = self.find(x)
        root_y = self.find(y)
        
        if root_x != root_y:
            if self.rank[root_x] < self.rank[root_y]:
                self.parent[root_x] = root_y
            elif self.rank[root_x] > self.rank[root_y]:
                self.parent[root_y] = root_x
            else:
                self.parent[root_y] = root_x
                self.rank[root_x] += 1
            return True  # 成功合并
        return False  # 已经在同一集合
def greedy_adjustment_with_mst(G, scores, entity_text_dict, B=2, lambda_weight=0.5):
    # 获取最大生成树
    mst = get_maximum_spanning_tree(G)
    
    # 找到所有的mention节点
    mention_nodes = [n for n in mst.nodes() if mst.nodes[n]['type'] == 'mention']
    
    final_predictions = []
    
    print(f"在MST上运行Algorithm 2贪心算法，处理{len(mention_nodes)}个mention...")
    
    for mention_id in mention_nodes:
        # ========== Algorithm 2 实现开始 ==========
        # 初始化
        uf = UnionFind()
        results = [mention_id]  # 结果集包含根提及
        edge_list = []  # 存储选择的边
        
        # 最大堆（Python的heapq是最小堆，用负权重实现最大堆）
        max_heap = []  # 存储(-weight, u, v)
        
        # 初始化：将mention到其实体的边加入堆
        for neighbor in mst.neighbors(mention_id):
            if mst.nodes[neighbor]['type'] == 'entity':
                weight = mst[mention_id][neighbor]['weight']
                heapq.heappush(max_heap, (-weight, mention_id, neighbor))
        
        # 初始化并查集
        uf.parent[mention_id] = mention_id
        uf.rank[mention_id] = 0
        
        # 主循环：直到选择了B个实体或堆为空
        selected_entities = 0
        
        while selected_entities < B and max_heap:
            # 弹出权重最大的边
            neg_weight, u, v = heapq.heappop(max_heap)
            weight = -neg_weight
            
            # 确保节点在并查集中初始化
            if v not in uf.parent:
                uf.parent[v] = v
                uf.rank[v] = 0
            
            # 检查是否形成环路
            if uf.find(u) != uf.find(v):
                # 不形成环路，加入结果
                uf.union(u, v)
                
                # 如果v是实体且不在结果中，加入结果集
                if mst.nodes[v]['type'] == 'entity' and v not in results:
                    results.append(v)
                    edge_list.append((u, v, weight))
                    selected_entities += 1
                    
                    # 动态扩展：将v的邻居边加入堆（Algorithm 2第10-11行）
                    for neighbor in mst.neighbors(v):
                        if neighbor not in results and (v, neighbor) in mst.edges():
                            neighbor_weight = mst[v][neighbor]['weight']
                            heapq.heappush(max_heap, (-neighbor_weight, v, neighbor))
        
        # ========== Algorithm 2 实现结束 ==========
        
        # 将结果转换为预测格式
        # results[0]是mention_id，后面的都是选择的实体
        selected_entity_ids = [node for node in results[1:] if mst.nodes[node]['type'] == 'entity']
        
        # 为每个选择的实体计算得分
        for entity_id in selected_entity_ids:
            # 计算该实体与mention的直接边权重作为得分
            # 或者用该实体在MST中的所有边平均权重
            if (mention_id, entity_id) in mst.edges():
                # 如果有直接边，使用直接边的权重
                score_final = mst[mention_id][entity_id]['weight']
            else:
                # 否则计算该实体在MST中的平均边权重
                entity_edges = []
                for neighbor in mst.neighbors(entity_id):
                    if (entity_id, neighbor) in mst.edges():
                        weight = mst[entity_id][neighbor]['weight']
                        entity_edges.append(weight)
                
                if entity_edges:
                    score_final = sum(entity_edges) / len(entity_edges)
                else:
                    score_final = 0.0
            
            final_predictions.append({
                "mention_id": mention_id,
                "pred_entity_id": entity_id,
                "score_final": round(score_final, 4)
            })
    
    return final_predictions, mst

def save_final_predictions(predictions, output_path='outputs/final_predictions.jsonl'):
    """保存最终预测结果到JSONL文件"""
    with open(output_path, 'w', encoding='utf-8') as f:
        for pred in predictions:
            json_line = {
                "mention_id": pred["mention_id"],
                "pred_entity_id": pred["pred_entity_id"],
                "score_final": pred["score_final"]
            }
            f.write(json.dumps(json_line, ensure_ascii=False) + '\n')
    # print(f"预测结果已保存到: {output_path}")

# 主流程
def main():
    print("\nTree Cover")
    G = build_tree_cover(K=3)
    print(f" node numbers: {G.number_of_nodes()}, edge numbers: {G.number_of_edges()}")
    # 重新加载数据（用于构建entity_text_dict）
    print("\nload data")
    scores = load_scores('outputs\\local_scores.jsonl')
    mentions = load_mentions('data\\mentions.json')
    
    # 构建entity_text_dict（与build_tree_cover中相同）
    entity_text_dict = {}
    for mention in mentions:
        for candidate in mention['candidates']:
            entity_id = candidate['entity_id']
            text = candidate['entity_title'] + " " + candidate['entity_desc']
            entity_text_dict[entity_id] = text
    print(f"  load {len(scores)} local_scores")
    print(f"  load {len(mentions)} mentions")
    
    # 进行贪心调整
    print("\ngreedy")
    final_predictions, mst = greedy_adjustment_with_mst(
        G, scores, entity_text_dict, B=2, lambda_weight=0.5
    )
    
    # 统计信息
    from collections import Counter
    mention_counts = Counter(pred["mention_id"] for pred in final_predictions)
    
    print(f"\nresult")
    print(f"  number of final_predictions: {len(final_predictions)}")
    print(f"  mentions: {len(mention_counts)}")
    
    # 显示每个mention的预测数分布
    count_distribution = Counter(mention_counts.values())
    print(f"  predictions:")
    for count, freq in sorted(count_distribution.items()):
        print(f"    {count} predicted_entities: {freq}个mention")  
    # 显示前几个预测
    print("\n5 predictions:")
    for pred in final_predictions[:5]:
        print(f"  {pred['mention_id']} -> {pred['pred_entity_id']}: {pred['score_final']}")
    
    # 保存结果
    print("\nsave the outcome")
    save_final_predictions(final_predictions)
if __name__ == "__main__":
    main()
