import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoModel
import time
import logging

logger = logging.getLogger(__name__)


class TextLocalScorer(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        logger.info(f"从本地路径加载BERT模型: {config.model_name}")
        start_time = time.time()

        try:
            self.bert = AutoModel.from_pretrained(
                config.model_name,
                cache_dir=config.cache_dir,
                local_files_only=True  # 强制使用本地文件
            )

            # 设置模型为评估模式
            self.bert.eval()

            load_time = time.time() - start_time
            logger.info(f"✅ BERT模型加载成功！耗时: {load_time:.2f}秒")

        except Exception as e:
            logger.error(f"BERT模型加载失败: {e}")
            logger.info("请检查模型文件是否完整")
            raise

        self.embedding_dim = self.bert.config.hidden_size
        self.pooling_strategy = config.pooling_strategy
        self.temperature = config.temperature

        # 可选的投影层
        self.projection = nn.Linear(self.embedding_dim, self.embedding_dim)
        self.layer_norm = nn.LayerNorm(self.embedding_dim)

        self.dropout = nn.Dropout(0.1)

    def _pool_embedding(self, last_hidden_state: torch.Tensor,
                        attention_mask: torch.Tensor) -> torch.Tensor:
        """池化策略获取文本表示"""
        if self.pooling_strategy == "cls":
            # 使用[CLS] token
            return last_hidden_state[:, 0, :]

        elif self.pooling_strategy == "mean":
            # 均值池化
            input_mask_expanded = attention_mask.unsqueeze(-1).expand(last_hidden_state.size()).float()
            sum_embeddings = torch.sum(last_hidden_state * input_mask_expanded, 1)
            sum_mask = torch.clamp(input_mask_expanded.sum(1), min=1e-9)
            return sum_embeddings / sum_mask

        elif self.pooling_strategy == "max":
            # 最大池化
            input_mask_expanded = attention_mask.unsqueeze(-1).expand(last_hidden_state.size()).float()
            last_hidden_state[input_mask_expanded == 0] = -1e9  # 将padding位置设为负无穷
            return torch.max(last_hidden_state, 1)[0]

        else:
            raise ValueError(f"Unknown pooling strategy: {self.pooling_strategy}")

    def forward(self, mention_input_ids, mention_attention_mask,
                entity_input_ids, entity_attention_mask):
        # 编码提及文本
        mention_outputs = self.bert(
            input_ids=mention_input_ids,
            attention_mask=mention_attention_mask
        )
        mention_embeddings = self._pool_embedding(
            mention_outputs.last_hidden_state,
            mention_attention_mask
        )

        # 编码实体描述
        entity_outputs = self.bert(
            input_ids=entity_input_ids,
            attention_mask=entity_attention_mask
        )
        entity_embeddings = self._pool_embedding(
            entity_outputs.last_hidden_state,
            entity_attention_mask
        )

        # 应用投影和归一化
        mention_embeddings = self.layer_norm(self.projection(mention_embeddings))
        entity_embeddings = self.layer_norm(self.projection(entity_embeddings))

        mention_embeddings = self.dropout(mention_embeddings)
        entity_embeddings = self.dropout(entity_embeddings)

        # 计算相似度
        if self.config.similarity_metric == "cosine":
            similarity = F.cosine_similarity(mention_embeddings, entity_embeddings, dim=-1)
        elif self.config.similarity_metric == "dot":
            similarity = torch.sum(mention_embeddings * entity_embeddings, dim=-1)
        else:
            raise ValueError(f"Unknown similarity metric: {self.config.similarity_metric}")

        # 应用温度缩放
        similarity = similarity / self.temperature

        return similarity, mention_embeddings, entity_embeddings