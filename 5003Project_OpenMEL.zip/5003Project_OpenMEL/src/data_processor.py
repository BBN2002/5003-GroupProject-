import json
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)


class EntityLinkingDataset(Dataset):
    def __init__(self, mentions_data: List[Dict], expanded_texts: Dict[str, str],
                 tokenizer: AutoTokenizer, config):
        self.mentions = mentions_data
        self.expanded_texts = expanded_texts
        self.tokenizer = tokenizer
        self.config = config
        self.samples = self._prepare_samples()

    def _prepare_samples(self) -> List[Dict]:
        """准备训练/推理样本"""
        samples = []

        for mention in self.mentions:
            mention_id = mention['mention_id']
            mention_text = mention['mention_text']

            # 获取扩写文本，如果没有则使用原始文本
            expanded_text = self.expanded_texts.get(mention_id, mention_text)

            # 拼接提及文本
            combined_mention = f"{mention_text} [SEP] {expanded_text}"

            for candidate in mention['candidates']:
                samples.append({
                    'mention_id': mention_id,
                    'entity_id': candidate['entity_id'],
                    'combined_mention': combined_mention,
                    'entity_desc': candidate['entity_desc'],
                    'label': candidate.get('label', 0)
                })

        logger.info(f"Prepared {len(samples)} mention-entity pairs")
        return samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        sample = self.samples[idx]

        # 编码提及文本
        mention_encoding = self.tokenizer(
            sample['combined_mention'],
            max_length=self.config.max_mention_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        # 编码实体描述
        entity_encoding = self.tokenizer(
            sample['entity_desc'],
            max_length=self.config.max_entity_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )

        return {
            'mention_id': sample['mention_id'],
            'entity_id': sample['entity_id'],
            'mention_input_ids': mention_encoding['input_ids'].squeeze(0),
            'mention_attention_mask': mention_encoding['attention_mask'].squeeze(0),
            'entity_input_ids': entity_encoding['input_ids'].squeeze(0),
            'entity_attention_mask': entity_encoding['attention_mask'].squeeze(0),
            'label': torch.tensor(sample['label'], dtype=torch.float)
        }


class DataProcessor:
    def __init__(self, config):
        self.config = config

        logger.info(f"从本地路径加载tokenizer: {config.model_name}")
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(
                config.model_name,
                cache_dir=config.cache_dir,
                local_files_only=True  # 强制使用本地文件
            )
            logger.info("✅ Tokenizer加载成功")

        except Exception as e:
            logger.error(f"Tokenizer加载失败: {e}")
            logger.info("请检查模型文件是否完整")
            raise

    def load_data(self):
        """加载所有必要的数据"""
        # 加载原始提及数据
        with open(self.config.mentions_path, 'r', encoding='utf-8') as f:
            mentions_data = json.load(f)

        # 加载LLM扩写结果
        expanded_texts = {}
        try:
            with open(self.config.expanded_path, 'r', encoding='utf-8') as f:
                for line in f:
                    data = json.loads(line.strip())
                    expanded_texts[data['mention_id']] = data['expanded_text']
        except FileNotFoundError:
            logger.warning(f"Expanded file not found: {self.config.expanded_path}")
            # 如果没有扩写文件，使用原始文本
            for mention in mentions_data:
                expanded_texts[mention['mention_id']] = mention['mention_text']

        logger.info(f"Loaded {len(mentions_data)} mentions and {len(expanded_texts)} expanded texts")
        return mentions_data, expanded_texts

    def create_dataloader(self, mentions_data: List[Dict], expanded_texts: Dict[str, str],
                          batch_size: int, shuffle: bool = False) -> DataLoader:
        """创建数据加载器"""
        dataset = EntityLinkingDataset(mentions_data, expanded_texts, self.tokenizer, self.config)

        dataloader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=shuffle,
            num_workers=0,  # 在Windows上设为0避免问题
            pin_memory=True
        )

        return dataloader