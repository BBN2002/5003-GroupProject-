import json
import pandas as pd
import matplotlib.pyplot as plt
import os

# 1. Configuration
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, 'data', 'mentions.json')
LOCAL_SCORES_PATH = os.path.join(BASE_DIR, 'outputs', 'local_scores.jsonl')
FINAL_PREDS_PATH = os.path.join(BASE_DIR, 'outputs', 'final_predictions.jsonl')
OUTPUT_IMG_PATH = os.path.join(BASE_DIR, 'outputs', 'accuracy_comparison.png')

def load_jsonl(file_path):
    """Read JSONL file"""
    data = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                data.append(json.loads(line))
    return data

def calculate_accuracy():
    print("Starting OpenMEL Text Module Evaluation...")

    # 2. Read Ground Truth
    with open(DATA_PATH, 'r', encoding='utf-8') as f:
        mentions = json.load(f)
    
    # Build a dictionary {mention_id: gold_entity_id}
    ground_truth = {m['mention_id']: m['gold_entity_id'] for m in mentions}
    total_mentions = len(ground_truth)
    print(f"Loaded {total_mentions} test samples (Ground Truth).")

    # 3. Evaluate Local Model (Baseline)
    # Local Scores file contains scores for all candidates; we need the max score.
    local_data = load_jsonl(LOCAL_SCORES_PATH)
    df_local = pd.DataFrame(local_data)
    
    # For each mention_id, find the row with the max local_score
    best_local = df_local.loc[df_local.groupby('mention_id')['local_score'].idxmax()]
    
    local_correct_count = 0
    for _, row in best_local.iterrows():
        mid = row['mention_id']
        pred_eid = row['entity_id']
        if mid in ground_truth and pred_eid == ground_truth[mid]:
            local_correct_count += 1
            
    acc_local = local_correct_count / total_mentions if total_mentions > 0 else 0
    print(f"[Baseline] Local Model Accuracy: {acc_local:.2%} ({local_correct_count}/{total_mentions})")

    # 4. Evaluate MST Global Optimization (Final)
    # Final Predictions file only contains the final selected entity.
    final_data = load_jsonl(FINAL_PREDS_PATH)
    
    final_correct_count = 0
    for row in final_data:
        mid = row['mention_id']
        # Note: Field name is usually 'pred_entity_id' based on docs
        pred_eid = row.get('pred_entity_id') 
        if mid in ground_truth and pred_eid == ground_truth[mid]:
            final_correct_count += 1

    acc_final = final_correct_count / total_mentions if total_mentions > 0 else 0
    print(f"[Ours] MST Global Optimization Accuracy: {acc_final:.2%} ({final_correct_count}/{total_mentions})")
    
    # 5. Visualization
    methods = ['LLM + Local', 'LLM + Local + MST']
    accuracies = [acc_local, acc_final]
    colors = ['#bdc3c7', '#3498db'] # Grey for baseline, Blue for advanced

    plt.figure(figsize=(8, 6))
    bars = plt.bar(methods, accuracies, color=colors, width=0.5)
    
    plt.ylim(0, 1.1)
    plt.ylabel('Accuracy@1')
    plt.title('Performance Comparison: Local vs Global (MST)')
    
    # Display values on top of bars
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height,
                 f'{height:.1%}',
                 ha='center', va='bottom', fontsize=12, fontweight='bold')

    plt.savefig(OUTPUT_IMG_PATH)
    print(f"Result chart saved to: {OUTPUT_IMG_PATH}")
    print("Evaluation Completed!")

if __name__ == "__main__":
    calculate_accuracy()