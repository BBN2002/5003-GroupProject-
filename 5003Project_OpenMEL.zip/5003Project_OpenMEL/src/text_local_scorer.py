import json
import logging
import os
import sys
import time
import torch

# 导入本地模块
from config import ModelConfig
from data_processor import DataProcessor
from model import TextLocalScorer
from trainer import InferenceEngine

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def verify_local_model(model_path):
    """验证本地模型完整性"""
    logger.info(f"验证本地模型: {model_path}")

    required_files = [
        'config.json',
        'vocab.txt',
        'tokenizer_config.json',
        'pytorch_model.bin'  # 或者 'model.safetensors'
    ]

    missing_files = []
    for file in required_files:
        file_path = os.path.join(model_path, file)
        if not os.path.exists(file_path):
            missing_files.append(file)

    if missing_files:
        logger.warning(f"模型文件缺失: {missing_files}")
        return False
    else:
        logger.info("✅ 模型文件完整")
        return True

def main():
    # 设置随机种子和确定性计算
    import random
    import numpy as np

    seed = 42  # 固定种子
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    logger.info(f"设置随机种子: {seed} 以确保结果可重现")

    # 记录开始时间
    start_time = time.time()
    logger.info("=== 文本Local打分系统启动（使用本地模型）===")

    # 初始化配置
    config = ModelConfig()

    # 验证本地模型
    if not verify_local_model(config.model_name):
        logger.error("本地模型不完整，请检查下载")
        return

    # 创建输出目录
    os.makedirs(os.path.dirname(config.output_path), exist_ok=True)
    logger.info("Initializing data processor...")

    # 初始化数据处理器
    logger.info("步骤 1/4: 初始化数据处理器...")
    data_processor = DataProcessor(config)

    # 加载数据
    logger.info("步骤 2/4: 加载数据...")
    mentions_data, expanded_texts = data_processor.load_data()

    if not mentions_data:
        logger.error("没有加载到数据，请检查输入文件。")
        return

    # 创建数据加载器
    logger.info("步骤 3/4: 创建数据加载器...")
    dataloader = data_processor.create_dataloader(
        mentions_data, expanded_texts,
        batch_size=config.batch_size,
        shuffle=False
    )

    # 初始化模型
    logger.info("步骤 4/4: 初始化模型...")
    model = TextLocalScorer(config)
    logger.info(f"模型初始化完成，参数数量: {sum(p.numel() for p in model.parameters()):,} ")

    # 推理模式
    logger.info("开始推理计算...")
    inference_engine = InferenceEngine(model, config)
    scores = inference_engine.predict_batch(dataloader)

    # 保存结果
    logger.info(f"Saving {len(scores)} scores to {config.output_path}")
    with open(config.output_path, 'w', encoding='utf-8') as f:
        for score in scores:
            f.write(json.dumps(score, ensure_ascii=False) + '\n')

    # 打印统计信息
    mention_scores = {}
    for score in scores:
        if score['mention_id'] not in mention_scores:
            mention_scores[score['mention_id']] = []
        mention_scores[score['mention_id']].append(score['local_score'])

    logger.info(f"Processed {len(mention_scores)} unique mentions")
    logger.info("Sample scores:")
    for i, (mention_id, scores_list) in enumerate(list(mention_scores.items())[:3]):
        logger.info(f"  {mention_id}: {len(scores_list)} candidates, "
                    f"score range [{min(scores_list):.3f}, {max(scores_list):.3f}]")

    logger.info("Text Local Scoring completed successfully!")


if __name__ == "__main__":
    main()