#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
将 data/mentions_raw.csv 转换为 data/mentions.json

输入 CSV 格式要求（每行一个候选实体）：
- mention_id
- doc_id
- mention_text
- gold_entity_id
- gold_entity_title
- entity_id
- entity_title
- entity_desc
- is_gold (0/1)

输出 JSON 为列表，每个元素是一个 mention，包含 candidates 列表。
"""

import csv
import json
import argparse
from collections import OrderedDict

def build_mentions(input_csv_path: str, output_json_path: str):
    mentions = OrderedDict()  # 保持顺序，方便调试

    with open(input_csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        required_cols = [
            "mention_id",
            "doc_id",
            "mention_text",
            "gold_entity_id",
            "gold_entity_title",
            "entity_id",
            "entity_title",
            "entity_desc",
            "is_gold",
        ]
        for col in required_cols:
            if col not in reader.fieldnames:
                raise ValueError(f"输入 CSV 缺少字段: {col}")

        for row in reader:
            mention_id = row["mention_id"].strip()
            if mention_id == "":
                raise ValueError("发现空的 mention_id，请检查 CSV。")

            if mention_id not in mentions:
                # 初始化一个新的 mention
                mentions[mention_id] = {
                    "mention_id": mention_id,
                    "doc_id": row["doc_id"].strip(),
                    "mention_text": row["mention_text"].strip(),
                    "gold_entity_id": row["gold_entity_id"].strip(),
                    "gold_entity_title": row["gold_entity_title"].strip(),
                    "candidates": [],
                }

            # 添加一个候选实体
            candidate = {
                "entity_id": row["entity_id"].strip(),
                "entity_title": row["entity_title"].strip(),
                "entity_desc": row["entity_desc"].strip(),
                "label": int(row["is_gold"]),
            }
            mentions[mention_id]["candidates"].append(candidate)

    # 转为列表输出
    mentions_list = list(mentions.values())

    with open(output_json_path, "w", encoding="utf-8") as f:
        json.dump(mentions_list, f, ensure_ascii=False, indent=2)

    print(f"成功生成 {output_json_path}，共 {len(mentions_list)} 条 mention。")

def main():
    parser = argparse.ArgumentParser(description="Build mentions.json from mentions_raw.csv")
    parser.add_argument(
        "--input",
        type=str,
        default="data/mentions_raw.csv",
        help="输入 CSV 路径（默认：data/mentions_raw.csv）",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="data/mentions.json",
        help="输出 JSON 路径（默认：data/mentions.json）",
    )
    args = parser.parse_args()

    build_mentions(args.input, args.output)

if __name__ == "__main__":
    main()