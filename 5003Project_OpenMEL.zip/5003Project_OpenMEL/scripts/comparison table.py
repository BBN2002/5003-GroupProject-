# Generate a comparison table of expansion results

import jsonlines

def clean_text(text: str) -> str:
    # The result has been saved to clean up unnecessary line breaks and spaces in the text
    return text.replace("\n", " ").replace("  ", " ").strip()

def extract_entity_type(expanded_text: str) -> str:
    # Extract entity type
    type_keywords = ["person", "company", "location", "organization", "programming language", "planet", "animal"]
    for keyword in type_keywords:
        if keyword in expanded_text.lower():
            return keyword
    return "unknown"

def generate_line_by_line_table(jsonl_path: str, output_md_path: str):
    data = []
    with jsonlines.open(jsonl_path, "r") as reader:
        for obj in reader:
            data.append({
                "id": obj.get("mention_id", ""),
                "original": clean_text(obj.get("mention_text", "")),
                "expanded": clean_text(obj.get("expanded_text", "")),
                "type": extract_entity_type(obj.get("expanded_text", ""))
            })
    
    md_content = "# Comparison Table of Expanded Results\n\n"
    for idx, item in enumerate(data, 1):
        md_content += f"###\n"
        md_content += f"- **mid**：{item['id']}\n"
        md_content += f"- **Original text**：{item['original']}\n"
        md_content += f"- **Expanded results**：{item['expanded']}\n"
        md_content += f"- **Entity type**：{item['type']}\n\n"
    
    with open(output_md_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    
    print(f"The table has been generated：{output_md_path}")

if __name__ == "__main__":
    generate_line_by_line_table("mentions_expanded.jsonl", "Comparison_Table_of_Expanded_Results.md")
