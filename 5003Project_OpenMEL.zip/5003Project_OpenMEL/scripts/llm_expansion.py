import json
import jsonlines
import requests
import time
from requests.exceptions import Timeout, ConnectionError

def load_mentions(input_path: str) -> list:
    try:
        with open(input_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"File {input_path} not found! ！")
        return []
    except Exception as e:
        print(f"Fail to read file：{str(e)}")
        return []

def call_llama3(prompt: str, model_name: str = "llama3:8b-instruct-q4_K_M") -> str:
    url = "http://localhost:11434/api/generate"
    payload = {
        "model": model_name,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.3,
            "max_tokens": 200,
            "top_p": 0.9,
            "timeout": 60
        }
    }
    
    try:
        # Connection timeout of 10 seconds, read timeout of 1 minute
        response = requests.post(url, json=payload, timeout=(10, 300))
        response.raise_for_status()
        return response.json()["response"].strip()
    except Timeout:
        print("Model call timeout!")
        return ""
    except ConnectionError:
        print("Unable to connect to Ollama service, please confirm that the service has been started.")
        return ""
    except Exception as e:
        print(f"Model call failed：{str(e)}")
        return ""

def build_prompt(original_mention: str) -> str:
    special_note = ""
    if "Washington" in original_mention:
        special_note = "NOTE: 'Washington' refers to the US government or Washington D.C. (location), clearly state which entity type it is (organization or location)!\n"
    
    system_prompt = special_note + """You MUST follow these rules to expand the mention text:
1. First, IDENTIFY the core entity in the mention (e.g., Washington = US government).
2. CLEARLY state the entity's TYPE (use one of these words: person, company, location, organization, programming language, planet, animal) in the first sentence.
3. Add 2-3 key attributes of the entity (e.g., function, location, authority).
4. LINK the expansion to the ORIGINAL mention's context (e.g., "not responding to Europe's proposal" = diplomatic negotiation).
5. Write a DETAILED paragraph (60-120 words), NO short sentences.
6. MUST include the core noun "Washington" in the expansion."""
    
    user_prompt = f"Expand this mention text: {original_mention}"
    
    full_prompt = f"<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n{system_prompt}<|eot_id|><|start_header_id|>user<|end_header_id|>\n{user_prompt}<|eot_id|><|start_header_id|>assistant<|end_header_id|>"
    return full_prompt

def validate_expansion(original: str, expanded: str) -> bool:
    if not expanded or len(expanded.split()) < 30:
        return False
    
    # 1. Must include entity type
    type_keywords = ["person", "company", "location", "programming language", "planet", "animal"]
    has_type = any(keyword in expanded.lower() for keyword in type_keywords)
    
    # 2. Must include the core nouns of the original text
    original_core = [w.lower() for w in original.split() if (w[0].isupper() or w in ["python", "mercury", "jordan"])]
    if not original_core:
        return has_type
    has_core = any(core in expanded.lower() for core in original_core)
    
    return has_type and has_core

def main():
    INPUT_FILE = "mentions.json"
    OUTPUT_FILE = "mentions_expanded.jsonl"
    
    mentions = load_mentions(INPUT_FILE)
    if not mentions:
        return
    
    expanded_results = []
    total = len(mentions)
    print(f"Start processing {total} pieces of data...\n")
    
    for idx, mention in enumerate(mentions):
        m_id = mention.get("mention_id")
        original_mention = mention.get("mention_text")
        if not m_id or not original_mention:
            print(f"Skip invalid data: Article {idx+1}\n")
            continue
        
        print(f"{idx+1}/{total} | ID: {m_id}")
        print(f"mention_text：{original_mention}")
        
        # Try again up to 3 times
        expanded_text = ""
        for retry in range(3):
            expanded_text = call_llama3(build_prompt(original_mention))
            if expanded_text:
                break
            time.sleep(5)
        
        # Display the results
        if validate_expansion(original_mention, expanded_text):
            print(f"Expanded results：{expanded_text}\n")
            expanded_results.append({
                "mention_id": m_id,
                "mention_text": original_mention,
                "expanded_text": expanded_text,
                "gold_entity_title": mention.get("gold_entity_title")
            })
        else:
            print(f"Expansion failed, try manually checking the prompt and retry\n")
    
    # Save results
    with jsonlines.open(OUTPUT_FILE, "w") as writer:
        writer.write_all(expanded_results)
    
    print(f"\nAccomplished！")
    print(f"Initial data：{total}")
    print(f"Effective expansion：{len(expanded_results)}")
    print(f"The result has been saved to：{OUTPUT_FILE}")

if __name__ == "__main__":
    main()
